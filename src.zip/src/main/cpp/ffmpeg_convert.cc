/*
 * RetroBars TV converter: turns any video FFmpeg can read (MKV, TS, AVI, FLV, MPG/VOB, WMV/ASF ...)
 * into an MP4 a Chromecast can play.
 *
 *  - H.264 / HEVC video is copied untouched (fast); other video is decoded with FFmpeg and
 *    re-encoded to H.264 with the phone's hardware encoder (MediaCodec, via FFmpeg).
 *  - AAC audio is copied; anything else (AC3, E-AC3, DTS, TrueHD, WMA, MP3, ...) is decoded and
 *    encoded to stereo AAC with FFmpeg's own (LGPL) AAC encoder.
 */
#include <android/log.h>
#include <errno.h>
#include <jni.h>
#include <sys/stat.h>
#include <unistd.h>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/audio_fifo.h>
#include <libavutil/channel_layout.h>
#include <libavutil/opt.h>
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
}

#define LOG_TAG "ffmpeg_convert"
#define LOGE(...) ((void)__android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__))
#define LOGI(...) ((void)__android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__))

// Must match FfmpegConverter.java.
static const int RESULT_OK = 0;
static const int RESULT_CANCELLED = 1;
static const int ERROR_INPUT = -1;
static const int ERROR_NO_VIDEO = -2;
static const int ERROR_VIDEO = -3;
static const int ERROR_AUDIO = -4;
static const int ERROR_OUTPUT = -5;

static const AVRational US = {1, 1000000};

namespace {

struct FdIo {
  int fd;
  int64_t size;
};

int readFd(void* opaque, uint8_t* buf, int size) {
  auto* io = (FdIo*)opaque;
  ssize_t n = read(io->fd, buf, size);
  if (n == 0) return AVERROR_EOF;
  if (n < 0) return AVERROR(errno);
  return (int)n;
}

int64_t seekFd(void* opaque, int64_t offset, int whence) {
  auto* io = (FdIo*)opaque;
  if (whence & AVSEEK_SIZE) return io->size >= 0 ? io->size : AVERROR(ENOSYS);
  whence &= ~AVSEEK_FORCE;
  off64_t r = lseek64(io->fd, offset, whence);
  return r < 0 ? AVERROR(errno) : r;
}

void logError(const char* what, int err) {
  char buf[128];
  av_strerror(err, buf, sizeof(buf));
  LOGE("%s: %s", what, buf);
}

struct Progress {
  JNIEnv* env;
  jobject listener;
  jmethodID onProgress;
  jmethodID isCancelled;
  int last = -1;

  bool cancelled() {
    return listener && env->CallBooleanMethod(listener, isCancelled);
  }

  void report(int percent) {
    if (!listener || percent == last) return;
    last = percent;
    env->CallVoidMethod(listener, onProgress, percent);
  }
};

struct Converter {
  AVFormatContext* in = nullptr;
  AVFormatContext* out = nullptr;
  AVIOContext* inIo = nullptr;
  FdIo fdIo{};
  int64_t startUs = 0;

  // Video
  int vIndex = -1;
  AVStream* vOut = nullptr;
  bool vCopy = true;
  AVCodecContext* vDec = nullptr;
  AVCodecContext* vEnc = nullptr;
  SwsContext* sws = nullptr;
  AVFrame* vFrame = nullptr;
  AVFrame* vScaled = nullptr;

  // Audio
  int aIndex = -1;
  AVStream* aOut = nullptr;
  bool aCopy = true;
  AVCodecContext* aDec = nullptr;
  AVCodecContext* aEnc = nullptr;
  SwrContext* swr = nullptr;
  AVAudioFifo* fifo = nullptr;
  AVFrame* aFrame = nullptr;
  int64_t aNextPts = AV_NOPTS_VALUE;  // in aEnc->time_base

  AVPacket* pkt = nullptr;
  AVPacket* encPkt = nullptr;

  ~Converter() {
    avcodec_free_context(&vDec);
    avcodec_free_context(&vEnc);
    avcodec_free_context(&aDec);
    avcodec_free_context(&aEnc);
    sws_freeContext(sws);
    swr_free(&swr);
    if (fifo) av_audio_fifo_free(fifo);
    av_frame_free(&vFrame);
    av_frame_free(&vScaled);
    av_frame_free(&aFrame);
    av_packet_free(&pkt);
    av_packet_free(&encPkt);
    if (in) avformat_close_input(&in);
    if (inIo) {
      av_freep(&inIo->buffer);
      avio_context_free(&inIo);
    }
    if (out) {
      if (out->pb) avio_closep(&out->pb);
      avformat_free_context(out);
    }
  }

  int64_t toOutUs(int64_t ts, AVRational tb) const {
    return av_rescale_q(ts, tb, US) - startUs;
  }

  int writeEncoded(AVCodecContext* enc, AVStream* st) {
    while (true) {
      int ret = avcodec_receive_packet(enc, encPkt);
      if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF) return 0;
      if (ret < 0) return ret;
      av_packet_rescale_ts(encPkt, enc->time_base, st->time_base);
      encPkt->stream_index = st->index;
      ret = av_interleaved_write_frame(out, encPkt);
      if (ret < 0) return ret;
    }
  }

  // ---- Video ----

  int openVideo(bool forceH264) {
    AVStream* st = in->streams[vIndex];
    AVCodecID id = st->codecpar->codec_id;
    vCopy = !forceH264 && (id == AV_CODEC_ID_H264 || id == AV_CODEC_ID_HEVC);
    vOut = avformat_new_stream(out, nullptr);
    if (!vOut) return AVERROR(ENOMEM);
    if (vCopy) {
      avcodec_parameters_copy(vOut->codecpar, st->codecpar);
      vOut->codecpar->codec_tag = id == AV_CODEC_ID_HEVC ? MKTAG('h', 'v', 'c', '1') : 0;
      vOut->time_base = st->time_base;
      return 0;
    }
    const AVCodec* dec = avcodec_find_decoder(id);
    if (!dec) return AVERROR_DECODER_NOT_FOUND;
    vDec = avcodec_alloc_context3(dec);
    avcodec_parameters_to_context(vDec, st->codecpar);
    vDec->pkt_timebase = st->time_base;
    vDec->thread_count = 4;
    int ret = avcodec_open2(vDec, dec, nullptr);
    if (ret < 0) return ret;

    const AVCodec* enc = avcodec_find_encoder_by_name("h264_mediacodec");
    if (!enc) return AVERROR_ENCODER_NOT_FOUND;
    vEnc = avcodec_alloc_context3(enc);
    int w = vDec->width;
    int h = vDec->height;
    // Keep it within 1080p so every phone's hardware encoder (and every Chromecast) copes.
    if (w > 1920 || h > 1080) {
      double scale = w * 1080 > h * 1920 ? 1920.0 / w : 1080.0 / h;
      w = (int)(w * scale);
      h = (int)(h * scale);
    }
    w &= ~1;
    h &= ~1;
    AVRational fps = av_guess_frame_rate(in, st, nullptr);
    if (fps.num <= 0 || fps.den <= 0 || av_q2d(fps) > 120) fps = AVRational{30, 1};
    vEnc->width = w;
    vEnc->height = h;
    vEnc->pix_fmt = AV_PIX_FMT_NV12;
    vEnc->time_base = US;
    vEnc->framerate = fps;
    vEnc->sample_aspect_ratio = vDec->sample_aspect_ratio;
    int64_t bitrate = (int64_t)(w * (int64_t)h * av_q2d(fps) * 0.12);
    vEnc->bit_rate = bitrate < 2000000 ? 2000000 : bitrate > 12000000 ? 12000000 : bitrate;
    vEnc->gop_size = (int)(av_q2d(fps) * 2);
    vEnc->max_b_frames = 0;
    vEnc->profile = AV_PROFILE_H264_HIGH;
    AVDictionary* opts = nullptr;
    av_dict_set(&opts, "ndk_codec", "1", 0);
    ret = avcodec_open2(vEnc, enc, &opts);
    av_dict_free(&opts);
    if (ret < 0) {
      // Some encoders don't do High profile from buffers; try the default profile.
      avcodec_free_context(&vEnc);
      vEnc = avcodec_alloc_context3(enc);
      vEnc->width = w;
      vEnc->height = h;
      vEnc->pix_fmt = AV_PIX_FMT_NV12;
      vEnc->time_base = US;
      vEnc->framerate = fps;
      vEnc->bit_rate = bitrate < 2000000 ? 2000000 : bitrate > 12000000 ? 12000000 : bitrate;
      vEnc->gop_size = (int)(av_q2d(fps) * 2);
      av_dict_set(&opts, "ndk_codec", "1", 0);
      ret = avcodec_open2(vEnc, enc, &opts);
      av_dict_free(&opts);
      if (ret < 0) return ret;
    }
    avcodec_parameters_from_context(vOut->codecpar, vEnc);
    vOut->time_base = US;
    vFrame = av_frame_alloc();
    vScaled = av_frame_alloc();
    vScaled->format = AV_PIX_FMT_NV12;
    vScaled->width = w;
    vScaled->height = h;
    ret = av_frame_get_buffer(vScaled, 0);
    return ret;
  }

  int encodeVideoFrame(AVFrame* frame) {
    if (frame) {
      int64_t ts = frame->best_effort_timestamp != AV_NOPTS_VALUE ? frame->best_effort_timestamp : frame->pts;
      if (ts == AV_NOPTS_VALUE) return 0;
      sws = sws_getCachedContext(sws, frame->width, frame->height, (AVPixelFormat)frame->format,
                                 vEnc->width, vEnc->height, AV_PIX_FMT_NV12, SWS_BILINEAR, nullptr,
                                 nullptr, nullptr);
      if (!sws) return AVERROR(EINVAL);
      int ret = av_frame_make_writable(vScaled);
      if (ret < 0) return ret;
      sws_scale(sws, frame->data, frame->linesize, 0, frame->height, vScaled->data, vScaled->linesize);
      int64_t us = toOutUs(ts, in->streams[vIndex]->time_base);
      if (us < 0) return 0;
      vScaled->pts = us;
      ret = avcodec_send_frame(vEnc, vScaled);
      if (ret < 0 && ret != AVERROR(EAGAIN)) return ret;
    } else {
      avcodec_send_frame(vEnc, nullptr);
    }
    return writeEncoded(vEnc, vOut);
  }

  int decodeVideo(AVPacket* p) {
    int ret = avcodec_send_packet(vDec, p);
    if (ret < 0 && ret != AVERROR(EAGAIN) && ret != AVERROR_EOF) {
      return ret == AVERROR_INVALIDDATA ? 0 : ret;  // skip damaged frames
    }
    while (true) {
      ret = avcodec_receive_frame(vDec, vFrame);
      if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF) return 0;
      if (ret < 0) return ret == AVERROR_INVALIDDATA ? 0 : ret;
      ret = encodeVideoFrame(vFrame);
      av_frame_unref(vFrame);
      if (ret < 0) return ret;
    }
  }

  // ---- Audio ----

  int openAudio() {
    AVStream* st = in->streams[aIndex];
    aCopy = st->codecpar->codec_id == AV_CODEC_ID_AAC && st->codecpar->ch_layout.nb_channels <= 2;
    aOut = avformat_new_stream(out, nullptr);
    if (!aOut) return AVERROR(ENOMEM);
    if (aCopy) {
      avcodec_parameters_copy(aOut->codecpar, st->codecpar);
      aOut->codecpar->codec_tag = 0;
      aOut->time_base = st->time_base;
      return 0;
    }
    const AVCodec* dec = avcodec_find_decoder(st->codecpar->codec_id);
    if (!dec) return AVERROR_DECODER_NOT_FOUND;
    aDec = avcodec_alloc_context3(dec);
    avcodec_parameters_to_context(aDec, st->codecpar);
    aDec->pkt_timebase = st->time_base;
    int ret = avcodec_open2(aDec, dec, nullptr);
    if (ret < 0) return ret;
    if (aDec->ch_layout.order == AV_CHANNEL_ORDER_UNSPEC) {
      int n = aDec->ch_layout.nb_channels > 0 ? aDec->ch_layout.nb_channels : 2;
      av_channel_layout_uninit(&aDec->ch_layout);
      av_channel_layout_default(&aDec->ch_layout, n);
    }

    const AVCodec* enc = avcodec_find_encoder(AV_CODEC_ID_AAC);
    if (!enc) return AVERROR_ENCODER_NOT_FOUND;
    aEnc = avcodec_alloc_context3(enc);
    int rate = aDec->sample_rate;
    if (rate != 48000 && rate != 44100 && rate != 32000) rate = 48000;
    aEnc->sample_rate = rate;
    aEnc->sample_fmt = AV_SAMPLE_FMT_FLTP;
    av_channel_layout_from_mask(&aEnc->ch_layout, AV_CH_LAYOUT_STEREO);
    aEnc->bit_rate = 192000;
    aEnc->time_base = AVRational{1, rate};
    if (out->oformat->flags & AVFMT_GLOBALHEADER) aEnc->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;
    ret = avcodec_open2(aEnc, enc, nullptr);
    if (ret < 0) return ret;
    avcodec_parameters_from_context(aOut->codecpar, aEnc);
    aOut->time_base = aEnc->time_base;
    fifo = av_audio_fifo_alloc(AV_SAMPLE_FMT_FLTP, 2, aEnc->frame_size * 4);
    aFrame = av_frame_alloc();
    return fifo && aFrame ? 0 : AVERROR(ENOMEM);
  }

  int ensureResampler(const AVFrame* f) {
    if (swr) return 0;
    AVChannelLayout inLayout;
    if (f->ch_layout.nb_channels > 0 && f->ch_layout.order != AV_CHANNEL_ORDER_UNSPEC) {
      av_channel_layout_copy(&inLayout, &f->ch_layout);
    } else {
      av_channel_layout_default(&inLayout, f->ch_layout.nb_channels > 0 ? f->ch_layout.nb_channels : aDec->ch_layout.nb_channels);
    }
    int ret = swr_alloc_set_opts2(&swr, &aEnc->ch_layout, aEnc->sample_fmt, aEnc->sample_rate, &inLayout,
                                  (AVSampleFormat)f->format, f->sample_rate, 0, nullptr);
    av_channel_layout_uninit(&inLayout);
    if (ret < 0) return ret;
    return swr_init(swr);
  }

  int encodeFromFifo(bool flush) {
    int frameSize = aEnc->frame_size;
    while (av_audio_fifo_size(fifo) >= frameSize || (flush && av_audio_fifo_size(fifo) > 0)) {
      int n = FFMIN(frameSize, av_audio_fifo_size(fifo));
      AVFrame* f = av_frame_alloc();
      f->nb_samples = n;
      f->format = aEnc->sample_fmt;
      f->sample_rate = aEnc->sample_rate;
      av_channel_layout_copy(&f->ch_layout, &aEnc->ch_layout);
      int ret = av_frame_get_buffer(f, 0);
      if (ret < 0) {
        av_frame_free(&f);
        return ret;
      }
      av_audio_fifo_read(fifo, (void**)f->data, n);
      f->pts = aNextPts;
      aNextPts += n;
      ret = avcodec_send_frame(aEnc, f);
      av_frame_free(&f);
      if (ret < 0) return ret;
      ret = writeEncoded(aEnc, aOut);
      if (ret < 0) return ret;
    }
    return 0;
  }

  int pushAudio(const AVFrame* f) {
    int maxOut = swr_get_out_samples(swr, f ? f->nb_samples : 0);
    if (maxOut <= 0) return 0;
    uint8_t** buf = nullptr;
    int ret = av_samples_alloc_array_and_samples(&buf, nullptr, 2, maxOut, aEnc->sample_fmt, 0);
    if (ret < 0) return ret;
    int got = swr_convert(swr, buf, maxOut, f ? (const uint8_t**)f->extended_data : nullptr, f ? f->nb_samples : 0);
    if (got > 0) av_audio_fifo_write(fifo, (void**)buf, got);
    av_freep(&buf[0]);
    av_freep(&buf);
    return got < 0 ? got : 0;
  }

  int decodeAudio(AVPacket* p) {
    int ret = avcodec_send_packet(aDec, p);
    if (ret < 0 && ret != AVERROR(EAGAIN) && ret != AVERROR_EOF) {
      return ret == AVERROR_INVALIDDATA ? 0 : ret;
    }
    while (true) {
      ret = avcodec_receive_frame(aDec, aFrame);
      if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF) return 0;
      if (ret < 0) return ret == AVERROR_INVALIDDATA ? 0 : ret;
      if (aNextPts == AV_NOPTS_VALUE) {
        int64_t ts = aFrame->best_effort_timestamp != AV_NOPTS_VALUE ? aFrame->best_effort_timestamp : aFrame->pts;
        int64_t us = ts == AV_NOPTS_VALUE ? 0 : toOutUs(ts, in->streams[aIndex]->time_base);
        aNextPts = av_rescale_q(us > 0 ? us : 0, US, aEnc->time_base);
      }
      ret = ensureResampler(aFrame);
      if (ret >= 0) ret = pushAudio(aFrame);
      av_frame_unref(aFrame);
      if (ret < 0) return ret;
      ret = encodeFromFifo(false);
      if (ret < 0) return ret;
    }
  }

  int copyPacket(AVPacket* p, AVStream* inSt, AVStream* outSt) {
    if (p->dts == AV_NOPTS_VALUE && p->pts == AV_NOPTS_VALUE) return 0;
    int64_t offset = av_rescale_q(startUs, US, inSt->time_base);
    if (p->pts != AV_NOPTS_VALUE) p->pts -= offset;
    if (p->dts != AV_NOPTS_VALUE) p->dts -= offset;
    av_packet_rescale_ts(p, inSt->time_base, outSt->time_base);
    p->stream_index = outSt->index;
    p->pos = -1;
    return av_interleaved_write_frame(out, p);
  }
};

}  // namespace

extern "C" JNIEXPORT jint JNICALL Java_androidx_media3_decoder_ffmpeg_FfmpegConverter_ffmpegConvert(
    JNIEnv* env, jclass clazz, jint fd, jstring outPath, jboolean forceH264, jobject listener) {
  Progress progress{env, listener, nullptr, nullptr};
  if (listener) {
    jclass lc = env->GetObjectClass(listener);
    progress.onProgress = env->GetMethodID(lc, "onProgress", "(I)V");
    progress.isCancelled = env->GetMethodID(lc, "isCancelled", "()Z");
    if (!progress.onProgress || !progress.isCancelled) return ERROR_INPUT;
  }

  Converter c;
  struct stat st {};
  c.fdIo.fd = fd;
  c.fdIo.size = fstat(fd, &st) == 0 ? st.st_size : -1;
  lseek64(fd, 0, SEEK_SET);

  // ---- Input ----
  const int ioSize = 64 * 1024;
  auto* ioBuffer = (uint8_t*)av_malloc(ioSize);
  c.inIo = avio_alloc_context(ioBuffer, ioSize, 0, &c.fdIo, readFd, nullptr, seekFd);
  c.in = avformat_alloc_context();
  if (!c.inIo || !c.in) return ERROR_INPUT;
  c.in->pb = c.inIo;
  c.in->flags |= AVFMT_FLAG_CUSTOM_IO | AVFMT_FLAG_GENPTS;
  int ret = avformat_open_input(&c.in, nullptr, nullptr, nullptr);
  if (ret < 0) {
    logError("open input", ret);
    return ERROR_INPUT;
  }
  ret = avformat_find_stream_info(c.in, nullptr);
  if (ret < 0) {
    logError("stream info", ret);
    return ERROR_INPUT;
  }
  c.vIndex = av_find_best_stream(c.in, AVMEDIA_TYPE_VIDEO, -1, -1, nullptr, 0);
  c.aIndex = av_find_best_stream(c.in, AVMEDIA_TYPE_AUDIO, -1, c.vIndex, nullptr, 0);
  if (c.vIndex < 0) return ERROR_NO_VIDEO;
  if (c.in->streams[c.vIndex]->disposition & AV_DISPOSITION_ATTACHED_PIC) return ERROR_NO_VIDEO;
  c.startUs = c.in->start_time != AV_NOPTS_VALUE ? c.in->start_time : 0;
  int64_t durationUs = c.in->duration > 0 ? c.in->duration : 0;

  // ---- Output ----
  const char* path = env->GetStringUTFChars(outPath, nullptr);
  ret = avformat_alloc_output_context2(&c.out, nullptr, "mp4", path);
  if (ret >= 0) ret = avio_open(&c.out->pb, path, AVIO_FLAG_WRITE);
  env->ReleaseStringUTFChars(outPath, path);
  if (ret < 0) {
    logError("open output", ret);
    return ERROR_OUTPUT;
  }

  ret = c.openVideo(forceH264);
  if (ret < 0) {
    logError("video", ret);
    return ERROR_VIDEO;
  }
  if (c.aIndex >= 0) {
    ret = c.openAudio();
    if (ret < 0) {
      logError("audio", ret);
      return ERROR_AUDIO;
    }
  }
  for (unsigned i = 0; i < c.in->nb_streams; i++) {
    if ((int)i != c.vIndex && (int)i != c.aIndex) c.in->streams[i]->discard = AVDISCARD_ALL;
  }

  AVDictionary* muxOpts = nullptr;
  av_dict_set(&muxOpts, "movflags", "+faststart", 0);
  ret = avformat_write_header(c.out, &muxOpts);
  av_dict_free(&muxOpts);
  if (ret < 0) {
    logError("write header", ret);
    return ERROR_OUTPUT;
  }
  LOGI("Converting: video %s, audio %s", c.vCopy ? "copy" : "h264", c.aIndex < 0 ? "none" : c.aCopy ? "copy" : "aac");

  c.pkt = av_packet_alloc();
  c.encPkt = av_packet_alloc();
  int count = 0;
  while (true) {
    if ((++count & 31) == 0 && progress.cancelled()) return RESULT_CANCELLED;
    ret = av_read_frame(c.in, c.pkt);
    if (ret == AVERROR_EOF) break;
    if (ret < 0) {
      // A damaged file often still has most of the video; keep what we have.
      logError("read", ret);
      break;
    }
    int index = c.pkt->stream_index;
    AVStream* inSt = c.in->streams[index];
    if (durationUs > 0 && c.pkt->stream_index == c.vIndex && c.pkt->dts != AV_NOPTS_VALUE) {
      int64_t us = c.toOutUs(c.pkt->dts, inSt->time_base);
      progress.report((int)FFMAX(0, FFMIN(99, us * 100 / durationUs)));
    }
    if (c.pkt->stream_index == c.vIndex) {
      ret = c.vCopy ? c.copyPacket(c.pkt, inSt, c.vOut) : c.decodeVideo(c.pkt);
    } else if (c.pkt->stream_index == c.aIndex) {
      ret = c.aCopy ? c.copyPacket(c.pkt, inSt, c.aOut) : c.decodeAudio(c.pkt);
    } else {
      ret = 0;
    }
    av_packet_unref(c.pkt);
    if (ret < 0) {
      logError("convert", ret);
      return index == c.aIndex ? ERROR_AUDIO : ERROR_VIDEO;
    }
  }

  // Drain decoders and encoders.
  if (!c.vCopy) {
    c.decodeVideo(nullptr);
    c.encodeVideoFrame(nullptr);
  }
  if (c.aIndex >= 0 && !c.aCopy) {
    c.decodeAudio(nullptr);
    if (c.swr) c.pushAudio(nullptr);
    c.encodeFromFifo(true);
    avcodec_send_frame(c.aEnc, nullptr);
    c.writeEncoded(c.aEnc, c.aOut);
  }
  ret = av_write_trailer(c.out);
  if (ret < 0) {
    logError("write trailer", ret);
    return ERROR_OUTPUT;
  }
  progress.report(100);
  return RESULT_OK;
}
