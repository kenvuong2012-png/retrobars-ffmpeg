/*
 * Software video decoding with FFmpeg for RetroBars (MPEG-1/2, MPEG-4, H.263, DivX/MS-MPEG4,
 * WMV 7/8/9, VC-1, MJPEG, and H.264 / HEVC / VP8 / VP9 when the phone has no hardware decoder).
 *
 * Frames are converted to I420 and handed to Java in a VideoDecoderOutputBuffer, then drawn on
 * the player's Surface as YV12.
 */
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <jni.h>
#include <string.h>
#include <unistd.h>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
}

#define LOG_TAG "ffmpeg_video_jni"
#define LOGE(...) ((void)__android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__))

#define VIDEO_DECODER_FUNC(RETURN_TYPE, NAME, ...)                       \
  extern "C" {                                                           \
  JNIEXPORT RETURN_TYPE                                                  \
      Java_androidx_media3_decoder_ffmpeg_FfmpegVideoDecoder_##NAME(     \
          JNIEnv* env, jobject thiz, ##__VA_ARGS__);                     \
  }                                                                      \
  JNIEXPORT RETURN_TYPE                                                  \
      Java_androidx_media3_decoder_ffmpeg_FfmpegVideoDecoder_##NAME(     \
          JNIEnv* env, jobject thiz, ##__VA_ARGS__)

// Must match FfmpegVideoDecoder.
static const int VIDEO_DECODER_ERROR_INVALID_DATA = -1;
static const int VIDEO_DECODER_ERROR_OTHER = -2;
static const int YV12 = 0x32315659;  // HAL_PIXEL_FORMAT_YV12

struct VideoContext {
  AVCodecContext* codec = nullptr;
  AVPacket* packet = nullptr;
  AVFrame* frame = nullptr;     // the decoded frame waiting to be copied to Java
  bool hasFrame = false;
  SwsContext* sws = nullptr;
  ANativeWindow* window = nullptr;
  jobject windowSurface = nullptr;  // global ref of the Surface 'window' belongs to
  int windowWidth = 0;
  int windowHeight = 0;
};

static int receiveFrame(VideoContext* ctx) {
  av_frame_unref(ctx->frame);
  int ret = avcodec_receive_frame(ctx->codec, ctx->frame);
  if (ret == 0) {
    ctx->hasFrame = true;
    return 1;
  }
  if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF) return 0;
  return ret == AVERROR_INVALIDDATA ? VIDEO_DECODER_ERROR_INVALID_DATA : VIDEO_DECODER_ERROR_OTHER;
}

VIDEO_DECODER_FUNC(jlong, ffmpegVideoInitialize, jstring codecName, jbyteArray extraData,
                   jint width, jint height, jint threads) {
  const char* name = env->GetStringUTFChars(codecName, nullptr);
  const AVCodec* codec = avcodec_find_decoder_by_name(name);
  env->ReleaseStringUTFChars(codecName, name);
  if (!codec) {
    LOGE("Video codec not found.");
    return 0;
  }
  auto* ctx = new VideoContext();
  ctx->codec = avcodec_alloc_context3(codec);
  ctx->packet = av_packet_alloc();
  ctx->frame = av_frame_alloc();
  if (!ctx->codec || !ctx->packet || !ctx->frame) {
    LOGE("Allocation failed.");
    avcodec_free_context(&ctx->codec);
    av_packet_free(&ctx->packet);
    av_frame_free(&ctx->frame);
    delete ctx;
    return 0;
  }
  if (extraData) {
    jsize size = env->GetArrayLength(extraData);
    if (size > 0) {
      ctx->codec->extradata = (uint8_t*)av_mallocz(size + AV_INPUT_BUFFER_PADDING_SIZE);
      ctx->codec->extradata_size = size;
      env->GetByteArrayRegion(extraData, 0, size, (jbyte*)ctx->codec->extradata);
    }
  }
  // Container dimensions: WMV / VC-1 / MS-MPEG4 decoders need them.
  if (width > 0) ctx->codec->width = ctx->codec->coded_width = width;
  if (height > 0) ctx->codec->height = ctx->codec->coded_height = height;
  ctx->codec->thread_count = threads > 0 ? threads : 0;
  ctx->codec->thread_type = FF_THREAD_FRAME | FF_THREAD_SLICE;
  ctx->codec->err_recognition = AV_EF_IGNORE_ERR;
  ctx->codec->pkt_timebase = AVRational{1, 1000000};
  int ret = avcodec_open2(ctx->codec, codec, nullptr);
  if (ret < 0) {
    char buf[128];
    av_strerror(ret, buf, sizeof(buf));
    LOGE("avcodec_open2 failed: %s", buf);
    avcodec_free_context(&ctx->codec);
    av_packet_free(&ctx->packet);
    av_frame_free(&ctx->frame);
    delete ctx;
    return 0;
  }
  return (jlong)ctx;
}

/**
 * Sends one compressed frame. Returns 1 when a decoded frame is ready (read it with
 * ffmpegVideoGetFrame...), 0 when the decoder needs more input, or a negative error.
 */
VIDEO_DECODER_FUNC(jint, ffmpegVideoDecode, jlong jctx, jobject inputData, jint inputSize,
                   jlong timeUs, jboolean keyFrame) {
  auto* ctx = (VideoContext*)jctx;
  if (!ctx) return VIDEO_DECODER_ERROR_OTHER;
  ctx->hasFrame = false;
  av_packet_unref(ctx->packet);
  ctx->packet->data = (uint8_t*)env->GetDirectBufferAddress(inputData);
  ctx->packet->size = inputSize;
  ctx->packet->pts = timeUs;
  ctx->packet->dts = AV_NOPTS_VALUE;
  if (keyFrame) ctx->packet->flags |= AV_PKT_FLAG_KEY;
  int ret = avcodec_send_packet(ctx->codec, ctx->packet);
  if (ret == AVERROR(EAGAIN)) {
    // A frame is waiting: hand it out now and queue this packet behind it.
    int got = receiveFrame(ctx);
    if (got < 0) return got;
    ret = avcodec_send_packet(ctx->codec, ctx->packet);
    ctx->packet->data = nullptr;
    ctx->packet->size = 0;
    if (ret < 0 && ret != AVERROR(EAGAIN)) {
      return ret == AVERROR_INVALIDDATA ? VIDEO_DECODER_ERROR_INVALID_DATA : VIDEO_DECODER_ERROR_OTHER;
    }
    return got;
  }
  ctx->packet->data = nullptr;
  ctx->packet->size = 0;
  if (ret < 0) {
    return ret == AVERROR_INVALIDDATA ? VIDEO_DECODER_ERROR_INVALID_DATA : VIDEO_DECODER_ERROR_OTHER;
  }
  return receiveFrame(ctx);
}

/** Fills info with {width, height, colorspace} and returns the frame's timestamp in us. */
VIDEO_DECODER_FUNC(jlong, ffmpegVideoGetFrameInfo, jlong jctx, jintArray info) {
  auto* ctx = (VideoContext*)jctx;
  if (!ctx || !ctx->hasFrame) return -1;
  AVFrame* f = ctx->frame;
  jint values[3];
  values[0] = f->width;
  values[1] = f->height;
  switch (f->colorspace) {
    case AVCOL_SPC_BT709:
      values[2] = 2;  // COLORSPACE_BT709
      break;
    case AVCOL_SPC_BT2020_NCL:
    case AVCOL_SPC_BT2020_CL:
      values[2] = 3;  // COLORSPACE_BT2020
      break;
    default:
      values[2] = 1;  // COLORSPACE_BT601
      break;
  }
  env->SetIntArrayRegion(info, 0, 3, values);
  int64_t pts = f->best_effort_timestamp != AV_NOPTS_VALUE ? f->best_effort_timestamp : f->pts;
  return pts == AV_NOPTS_VALUE ? -1 : (jlong)pts;
}

/** Copies the frame as I420 into data (Y, then U, then V with the given strides). */
VIDEO_DECODER_FUNC(jboolean, ffmpegVideoCopyFrame, jlong jctx, jobject data, jint yStride,
                   jint uvStride) {
  auto* ctx = (VideoContext*)jctx;
  if (!ctx || !ctx->hasFrame) return JNI_FALSE;
  AVFrame* f = ctx->frame;
  auto* out = (uint8_t*)env->GetDirectBufferAddress(data);
  if (!out) return JNI_FALSE;
  int w = f->width;
  int h = f->height;
  int uvH = (h + 1) / 2;
  uint8_t* dst[4] = {out, out + (size_t)yStride * h, out + (size_t)yStride * h + (size_t)uvStride * uvH, nullptr};
  int dstStride[4] = {yStride, uvStride, uvStride, 0};
  auto fmt = (AVPixelFormat)f->format;
  if (fmt == AV_PIX_FMT_YUV420P || fmt == AV_PIX_FMT_YUVJ420P) {
    av_image_copy_plane(dst[0], yStride, f->data[0], f->linesize[0], w, h);
    av_image_copy_plane(dst[1], uvStride, f->data[1], f->linesize[1], (w + 1) / 2, uvH);
    av_image_copy_plane(dst[2], uvStride, f->data[2], f->linesize[2], (w + 1) / 2, uvH);
  } else {
    // 10-bit, 4:2:2, 4:4:4, NV12 ... : convert.
    ctx->sws = sws_getCachedContext(ctx->sws, w, h, fmt, w, h, AV_PIX_FMT_YUV420P, SWS_FAST_BILINEAR,
                                    nullptr, nullptr, nullptr);
    if (!ctx->sws) return JNI_FALSE;
    sws_scale(ctx->sws, f->data, f->linesize, 0, h, dst, dstStride);
  }
  ctx->hasFrame = false;
  av_frame_unref(f);
  return JNI_TRUE;
}

VIDEO_DECODER_FUNC(void, ffmpegVideoFlush, jlong jctx) {
  auto* ctx = (VideoContext*)jctx;
  if (!ctx) return;
  avcodec_flush_buffers(ctx->codec);
  ctx->hasFrame = false;
  av_frame_unref(ctx->frame);
}

VIDEO_DECODER_FUNC(void, ffmpegVideoRelease, jlong jctx) {
  auto* ctx = (VideoContext*)jctx;
  if (!ctx) return;
  avcodec_free_context(&ctx->codec);
  av_packet_free(&ctx->packet);
  av_frame_free(&ctx->frame);
  sws_freeContext(ctx->sws);
  if (ctx->window) ANativeWindow_release(ctx->window);
  if (ctx->windowSurface) env->DeleteGlobalRef(ctx->windowSurface);
  delete ctx;
}

/** Draws an I420 frame on the Surface as YV12. Returns false if the Surface couldn't be used. */
VIDEO_DECODER_FUNC(jboolean, ffmpegVideoRender, jlong jctx, jobject surface, jobject data,
                   jint width, jint height, jint yStride, jint uvStride) {
  auto* ctx = (VideoContext*)jctx;
  if (!ctx || !surface) return JNI_FALSE;
  if (!ctx->windowSurface || !env->IsSameObject(ctx->windowSurface, surface)) {
    if (ctx->window) ANativeWindow_release(ctx->window);
    if (ctx->windowSurface) env->DeleteGlobalRef(ctx->windowSurface);
    ctx->window = ANativeWindow_fromSurface(env, surface);
    ctx->windowSurface = env->NewGlobalRef(surface);
    ctx->windowWidth = 0;
    ctx->windowHeight = 0;
    if (!ctx->window) return JNI_FALSE;
  }
  if (ctx->windowWidth != width || ctx->windowHeight != height) {
    if (ANativeWindow_setBuffersGeometry(ctx->window, width, height, YV12)) return JNI_FALSE;
    ctx->windowWidth = width;
    ctx->windowHeight = height;
  }
  ANativeWindow_Buffer buffer;
  if (ANativeWindow_lock(ctx->window, &buffer, nullptr) || !buffer.bits) return JNI_FALSE;
  auto* src = (const uint8_t*)env->GetDirectBufferAddress(data);
  if (!src) {
    ANativeWindow_unlockAndPost(ctx->window);
    return JNI_FALSE;
  }
  int uvH = (height + 1) / 2;
  const uint8_t* srcY = src;
  const uint8_t* srcU = src + (size_t)yStride * height;
  const uint8_t* srcV = srcU + (size_t)uvStride * uvH;
  auto* dst = (uint8_t*)buffer.bits;
  int copyW = width < buffer.width ? width : buffer.width;
  int copyH = height < buffer.height ? height : buffer.height;
  for (int y = 0; y < copyH; y++) {
    memcpy(dst + (size_t)y * buffer.stride, srcY + (size_t)y * yStride, copyW);
  }
  // YV12: Y, then V (Cr), then U (Cb); chroma stride is the luma stride / 2 aligned to 16.
  int dstUvStride = ((buffer.stride / 2) + 15) & ~15;
  int dstUvH = (buffer.height + 1) / 2;
  uint8_t* dstV = dst + (size_t)buffer.stride * buffer.height;
  uint8_t* dstU = dstV + (size_t)dstUvStride * dstUvH;
  int copyUvW = (copyW + 1) / 2;
  int copyUvH = (copyH + 1) / 2;
  for (int y = 0; y < copyUvH; y++) {
    memcpy(dstV + (size_t)y * dstUvStride, srcV + (size_t)y * uvStride, copyUvW);
    memcpy(dstU + (size_t)y * dstUvStride, srcU + (size_t)y * uvStride, copyUvW);
  }
  ANativeWindow_unlockAndPost(ctx->window);
  return JNI_TRUE;
}
