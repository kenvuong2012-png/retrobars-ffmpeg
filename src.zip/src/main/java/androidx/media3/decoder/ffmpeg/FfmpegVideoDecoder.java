/*
 * Software video decoder backed by FFmpeg (RetroBars). Used when the phone has no hardware
 * decoder for a stream: MPEG-1/2, MPEG-4 Part 2, H.263, MS-MPEG4/DivX 3, WMV 7/8/9, VC-1, MJPEG,
 * and H.264 / HEVC / VP8 / VP9 as a last resort.
 */
package androidx.media3.decoder.ffmpeg;

import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.decoder.SimpleDecoder;
import androidx.media3.decoder.VideoDecoderOutputBuffer;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Objects;

@UnstableApi
/* package */ final class FfmpegVideoDecoder
    extends SimpleDecoder<DecoderInputBuffer, VideoDecoderOutputBuffer, FfmpegDecoderException> {

  // Must match ffmpeg_video_jni.cc.
  private static final int VIDEO_DECODER_ERROR_INVALID_DATA = -1;

  private final String codecName;
  private final int[] frameInfo = new int[3];
  private long nativeContext;
  private volatile @C.VideoOutputMode int outputMode = C.VIDEO_OUTPUT_MODE_NONE;

  public FfmpegVideoDecoder(
      int numInputBuffers, int numOutputBuffers, int initialInputBufferSize, int threads, Format format)
      throws FfmpegDecoderException {
    super(new DecoderInputBuffer[numInputBuffers], new VideoDecoderOutputBuffer[numOutputBuffers]);
    if (!FfmpegLibrary.isAvailable()) {
      throw new FfmpegDecoderException("Failed to load decoder native libraries.");
    }
    String mimeType = Objects.requireNonNull(format.sampleMimeType);
    String name = FfmpegLibrary.getCodecName(mimeType);
    if (name == null) {
      throw new FfmpegDecoderException("Unsupported video format: " + mimeType);
    }
    codecName = name;
    nativeContext =
        ffmpegVideoInitialize(
            codecName, getExtraData(mimeType, format.initializationData), format.width, format.height, threads);
    if (nativeContext == 0) {
      throw new FfmpegDecoderException("Failed to initialize " + codecName + " decoder.");
    }
    setInitialInputBufferSize(initialInputBufferSize);
  }

  /** H.264 / HEVC parameter sets arrive as separate NAL units; FFmpeg wants them in one block. */
  @Nullable
  private static byte[] getExtraData(String mimeType, List<byte[]> initializationData) {
    if (initializationData.isEmpty()) {
      return null;
    }
    if (MimeTypes.VIDEO_H264.equals(mimeType) || MimeTypes.VIDEO_H265.equals(mimeType)) {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      for (byte[] nal : initializationData) {
        out.write(nal, 0, nal.length);
      }
      return out.toByteArray();
    }
    return initializationData.get(0);
  }

  @Override
  public String getName() {
    return "ffmpeg" + FfmpegLibrary.getVersion() + "-" + codecName;
  }

  /** Sets the output mode: {@link C#VIDEO_OUTPUT_MODE_NONE} skips copying frames. */
  public void setOutputMode(@C.VideoOutputMode int outputMode) {
    this.outputMode = outputMode;
  }

  @Override
  protected DecoderInputBuffer createInputBuffer() {
    return new DecoderInputBuffer(
        DecoderInputBuffer.BUFFER_REPLACEMENT_MODE_DIRECT, FfmpegLibrary.getInputBufferPaddingSize());
  }

  @Override
  protected VideoDecoderOutputBuffer createOutputBuffer() {
    return new VideoDecoderOutputBuffer(this::releaseOutputBuffer);
  }

  @Override
  protected FfmpegDecoderException createUnexpectedDecodeException(Throwable error) {
    return new FfmpegDecoderException("Unexpected decode error", error);
  }

  @Nullable
  @Override
  protected FfmpegDecoderException decode(
      DecoderInputBuffer inputBuffer, VideoDecoderOutputBuffer outputBuffer, boolean reset) {
    if (reset) {
      ffmpegVideoFlush(nativeContext);
    }
    ByteBuffer data = Objects.requireNonNull(inputBuffer.data);
    int result =
        ffmpegVideoDecode(nativeContext, data, data.limit(), inputBuffer.timeUs, inputBuffer.isKeyFrame());
    if (result == VIDEO_DECODER_ERROR_INVALID_DATA) {
      // A damaged frame: skip it and carry on, like hardware decoders do.
      outputBuffer.shouldBeSkipped = true;
      return null;
    } else if (result < 0) {
      return new FfmpegDecoderException("Video decode error (" + codecName + ")");
    } else if (result == 0) {
      // The decoder is holding this frame back (B-frames / threading); nothing to show yet.
      outputBuffer.shouldBeSkipped = true;
      return null;
    }
    long timeUs = ffmpegVideoGetFrameInfo(nativeContext, frameInfo);
    if (timeUs < 0) {
      timeUs = inputBuffer.timeUs;
    }
    int mode = outputMode;
    outputBuffer.init(timeUs, mode, /* supplementalData= */ null);
    if (mode == C.VIDEO_OUTPUT_MODE_NONE) {
      return null;
    }
    int width = frameInfo[0];
    int height = frameInfo[1];
    int yStride = (width + 15) & ~15;
    int uvStride = (((width + 1) / 2) + 15) & ~15;
    if (!outputBuffer.initForYuvFrame(width, height, yStride, uvStride, frameInfo[2])
        || !ffmpegVideoCopyFrame(nativeContext, Objects.requireNonNull(outputBuffer.data), yStride, uvStride)) {
      outputBuffer.shouldBeSkipped = true;
    }
    return null;
  }

  /** Draws a decoded frame on the player's surface. */
  public void renderToSurface(VideoDecoderOutputBuffer outputBuffer, Surface surface)
      throws FfmpegDecoderException {
    if (outputBuffer.data == null) {
      return;
    }
    if (!ffmpegVideoRender(
        nativeContext,
        surface,
        outputBuffer.data,
        outputBuffer.width,
        outputBuffer.height,
        outputBuffer.yStride,
        outputBuffer.uvStride)) {
      throw new FfmpegDecoderException("Couldn't draw the video frame.");
    }
  }

  @Override
  public void release() {
    super.release();
    ffmpegVideoRelease(nativeContext);
    nativeContext = 0;
  }

  private native long ffmpegVideoInitialize(
      String codecName, @Nullable byte[] extraData, int width, int height, int threads);

  private native int ffmpegVideoDecode(
      long context, ByteBuffer inputData, int inputSize, long timeUs, boolean keyFrame);

  private native long ffmpegVideoGetFrameInfo(long context, int[] info);

  private native boolean ffmpegVideoCopyFrame(long context, ByteBuffer data, int yStride, int uvStride);

  private native void ffmpegVideoFlush(long context);

  private native void ffmpegVideoRelease(long context);

  private native boolean ffmpegVideoRender(
      long context, Surface surface, ByteBuffer data, int width, int height, int yStride, int uvStride);
}
