/*
 * RetroBars: converts a video to an MP4 a Chromecast can play, using FFmpeg (see ffmpeg_convert.cc).
 */
package androidx.media3.decoder.ffmpeg;

import androidx.annotation.Nullable;
import androidx.media3.common.util.UnstableApi;

/** Converts videos to MP4 (H.264 / HEVC + AAC) for casting. Calls block; run off the main thread. */
@UnstableApi
public final class FfmpegConverter {

  // Must match ffmpeg_convert.cc.
  public static final int RESULT_OK = 0;
  public static final int RESULT_CANCELLED = 1;
  public static final int ERROR_INPUT = -1;
  public static final int ERROR_NO_VIDEO = -2;
  public static final int ERROR_VIDEO = -3;
  public static final int ERROR_AUDIO = -4;
  public static final int ERROR_OUTPUT = -5;

  /** Progress and cancellation. Called on the converting thread. */
  public interface Listener {
    void onProgress(int percent);

    boolean isCancelled();
  }

  private FfmpegConverter() {}

  /** Whether the FFmpeg library is on this device (ARM phones). */
  public static boolean isAvailable() {
    return FfmpegLibrary.isAvailable();
  }

  /**
   * Converts the file open on {@code fd} (not closed) into an MP4 at {@code outputPath}.
   *
   * @param forceH264 Re-encode H.264-compatible output even when the source is HEVC.
   * @return {@link #RESULT_OK}, {@link #RESULT_CANCELLED} or one of the {@code ERROR_} values.
   */
  public static int convert(int fd, String outputPath, boolean forceH264, @Nullable Listener listener) {
    if (!FfmpegLibrary.isAvailable()) {
      return ERROR_INPUT;
    }
    return ffmpegConvert(fd, outputPath, forceH264, listener);
  }

  private static native int ffmpegConvert(
      int fd, String outputPath, boolean forceH264, @Nullable Listener listener);
}
